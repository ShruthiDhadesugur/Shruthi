package com.basicassignment;

public class Question1 {

	public static void main(String[] args) {
System.out.println("Hello World");
	}

}
